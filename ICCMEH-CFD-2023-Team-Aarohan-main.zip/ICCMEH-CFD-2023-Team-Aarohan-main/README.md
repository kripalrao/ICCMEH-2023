<p align="center">
  <img src="https://github.com/kanakaero/iccmeh-cfd-2023-team-aarohan/assets/93387754/d1bb4dfc-dc99-4685-8706-6b612651710f">
<p/>
<br/>

# ICCMEH 2023 CFD Competition Team Aarohan

This repository corresponds to our submission to the ICCMEH CFD competition 2023. We secured third place during the course of the competition.
