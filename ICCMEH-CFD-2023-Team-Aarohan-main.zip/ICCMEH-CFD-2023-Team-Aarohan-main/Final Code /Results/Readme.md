# Results

The final compiled results of the various optimisation cases run are stored here.
