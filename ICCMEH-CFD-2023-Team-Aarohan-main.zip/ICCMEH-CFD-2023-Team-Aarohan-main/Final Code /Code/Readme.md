# Final Code

This is the final version of the framework developed. The code only works in this folder since all the dependencies are defined here. 
