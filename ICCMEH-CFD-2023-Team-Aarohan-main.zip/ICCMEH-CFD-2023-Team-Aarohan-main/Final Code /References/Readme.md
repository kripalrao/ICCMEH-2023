# References

This directory elucidates the references used while developing the MATLAB framework.
